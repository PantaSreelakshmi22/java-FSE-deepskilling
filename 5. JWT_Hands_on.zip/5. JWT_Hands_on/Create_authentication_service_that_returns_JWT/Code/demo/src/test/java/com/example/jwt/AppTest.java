package com.example.jwt;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AppTest {

    @Test
    void sampleTest() {
        assertTrue(true); // This is a dummy test to pass the build
    }
}

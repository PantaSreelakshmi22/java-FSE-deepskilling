package com.cognizant.springlearn.util;

import com.cognizant.springlearn.model.Country;
import java.util.List;

public class CountryList {

    private List<Country> countryList;

    public List<Country> getCountryList() {
        return countryList;
    }

    public void setCountryList(List<Country> countryList) {
        this.countryList = countryList;
    }
}
